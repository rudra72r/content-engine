const GEMINI_MODEL = 'gemini-2.5-flash';
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

export function getStoredApiKey() {
  return localStorage.getItem('rj_api_key') || '';
}

export function hasClientApiKey() {
  return !!getStoredApiKey();
}

async function callDirect(reqBody) {
  const apiKey = getStoredApiKey();
  const res = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(reqBody)
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({ error: { message: 'Unknown API error' } }));
    throw new Error(errData.error?.message || `API error ${res.status}`);
  }

  return res.json();
}

async function callProxy(reqBody, options = {}) {
  const res = await fetch('/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...reqBody,
      model: options.model || GEMINI_MODEL,
      maxOutputTokens: options.maxOutputTokens
    })
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({ error: { message: 'Unknown API error' } }));
    if (res.status === 503) {
      throw new Error('Server API key not configured. Add your Gemini API key above or set GEMINI_API_KEY on the server.');
    }
    throw new Error(errData.error?.message || `API error ${res.status}`);
  }

  return res.json();
}

export async function generateContent(reqBody, options = {}) {
  if (hasClientApiKey()) {
    return callDirect(reqBody);
  }
  return callProxy(reqBody, options);
}

export function extractText(data) {
  const parts = data.candidates?.[0]?.content?.parts || [];
  const raw = parts.filter(p => p.text).map(p => p.text).join('');
  if (!raw.trim()) throw new Error('Empty response — try again');
  return raw;
}

export function parseJsonResponse(raw) {
  const clean = raw.replace(/```json|```/g, '').trim();
  const s = clean.indexOf('{');
  const e = clean.lastIndexOf('}');
  if (s === -1 || e === -1) throw new Error('Could not parse response — try again');
  return JSON.parse(clean.slice(s, e + 1));
}

export function buildRequestBody(userPrompt, liveOn, maxOutputTokens = 8192) {
  const reqBody = {
    system_instruction: { parts: [{ text: userPrompt.system }] },
    contents: [{ role: 'user', parts: [{ text: userPrompt.user }] }],
    generationConfig: { maxOutputTokens, temperature: 1.0 }
  };

  if (liveOn) {
    reqBody.tools = [{ google_search: {} }];
  }

  return reqBody;
}
