import { SYSTEM, buildPrompt } from './prompts.js';
import { generateContent, buildRequestBody, extractText, parseJsonResponse, getStoredApiKey } from './api.js';
import { renderResearch, renderPosts, copyPost, copyAll, regenOne, showErr } from './render.js';

let mode = 'single';
let liveOn = true;
let posts = [];
let apiKey = getStoredApiKey();

const LOADER_TEXTS = [
  'Scanning what your audience is debating...',
  'Fetching live tensions from Reddit and X...',
  'Finding the non-obvious angle...',
  'Applying PACC intelligence framework...',
  'Extracting sharpest hook...',
  'Writing in your voice...',
  'Checking against intelligence standard...',
  'Cutting everything that doesn\'t earn its place...'
];

function init() {
  if (apiKey) {
    document.getElementById('api-key-input').value = '••••••••••••••••';
    document.getElementById('api-status').textContent = 'Key saved ✓';
    document.getElementById('api-status').className = 'api-status ok';
  }

  document.getElementById('api-save-btn').addEventListener('click', saveKey);
  document.getElementById('raw-idea').addEventListener('input', onRawIdeaInput);
  document.getElementById('live-tgl').addEventListener('click', toggleLive);
  document.getElementById('gen-btn').addEventListener('click', generate);
  document.getElementById('week-btn').addEventListener('click', weekRun);
  document.querySelector('.copy-all-btn').addEventListener('click', () => copyAll(posts));

  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => setMode(btn.dataset.mode, parseInt(btn.dataset.idx, 10)));
  });

  document.getElementById('posts-wrap').addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const i = parseInt(btn.dataset.index, 10);
    if (btn.dataset.action === 'copy') copyPost(posts, i);
    if (btn.dataset.action === 'regen') regenOne(posts, i);
  });
}

function saveKey() {
  const statusEl = document.getElementById('api-status');
  const val = document.getElementById('api-key-input').value.trim();

  if (!val || val.startsWith('•')) {
    statusEl.textContent = 'Enter a valid API key';
    statusEl.className = 'api-status key-err';
    return;
  }
  if (val.length < 10) {
    statusEl.textContent = 'Enter a valid Gemini API key';
    statusEl.className = 'api-status key-err';
    return;
  }

  apiKey = val;
  localStorage.setItem('rj_api_key', val);
  document.getElementById('api-key-input').value = '••••••••••••••••';
  statusEl.textContent = 'Key saved ✓';
  statusEl.className = 'api-status ok';
}

function setMode(m, idx) {
  mode = m;
  for (let i = 0; i < 4; i++) document.getElementById('m' + i).classList.remove('on');
  document.getElementById('m' + idx).classList.add('on');
  if (m === 'thread') {
    document.getElementById('sel-platform').value = 'x';
    document.getElementById('sel-platform').disabled = true;
  } else {
    document.getElementById('sel-platform').disabled = false;
  }
}

function toggleLive() {
  liveOn = !liveOn;
  document.getElementById('live-tgl').classList.toggle('on', liveOn);
  document.getElementById('tgl-lbl').textContent = liveOn ? 'On' : 'Off';
}

function onRawIdeaInput(e) {
  e.target.nextElementSibling.textContent = e.target.value.length;
}

function weekRun() {
  setMode('week', 3);
  generate();
}

async function generate() {
  const genBtn = document.getElementById('gen-btn');
  const weekBtn = document.getElementById('week-btn');
  const loader = document.getElementById('loader');
  const output = document.getElementById('output');
  const research = document.getElementById('research-panel');
  const err = document.getElementById('err');
  const rule = document.getElementById('output-rule');

  genBtn.disabled = true;
  weekBtn.disabled = true;
  loader.classList.add('on');
  output.classList.remove('on');
  research.classList.remove('on');
  rule.style.display = 'none';
  err.classList.remove('on');

  let li = 0;
  const ltEl = document.getElementById('loader-txt');
  const interval = setInterval(() => {
    li = (li + 1) % LOADER_TEXTS.length;
    ltEl.textContent = LOADER_TEXTS[li];
  }, 1800);

  try {
    const userPrompt = buildPrompt(mode, liveOn);
    const reqBody = buildRequestBody({ system: SYSTEM, user: userPrompt }, liveOn);
    const data = await generateContent(reqBody);
    clearInterval(interval);
    loader.classList.remove('on');
    genBtn.disabled = false;
    weekBtn.disabled = false;

    const raw = extractText(data);
    const parsed = parseJsonResponse(raw);
    posts = parsed.posts || [];

    renderResearch(parsed.research_insights || []);
    renderPosts(posts);
  } catch (e) {
    clearInterval(interval);
    loader.classList.remove('on');
    genBtn.disabled = false;
    weekBtn.disabled = false;
    showErr('Error: ' + e.message + '. Check your API key and try again.');
  }
}

document.addEventListener('DOMContentLoaded', init);
