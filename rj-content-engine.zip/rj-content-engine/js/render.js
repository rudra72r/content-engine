import { generateContent, buildRequestBody, extractText, parseJsonResponse } from './api.js';
import { SYSTEM, buildRegenPrompt } from './prompts.js';

export const PACC_LABELS = {
  P: 'Psychology Trigger',
  A: 'Articulation',
  C1: 'Confidence Signal',
  C2: 'Community Signal',
  PA: 'Psychology + Articulation',
  PAC: 'P + A + Confidence',
  PACC: 'Full PACC'
};

export function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

export function showErr(msg) {
  const el = document.getElementById('err');
  el.textContent = msg;
  el.classList.add('on');
  el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

export function renderResearch(insights) {
  if (!insights.length) return;
  const panel = document.getElementById('research-panel');
  const items = document.getElementById('research-items');
  items.innerHTML = insights.map(r => {
    const t = typeof r === 'string' ? r : (r.tension || '');
    const d = typeof r === 'string' ? '' : (r.detail || '');
    return `<div class="r-item"><strong>${esc(t)}</strong>${d ? ' — ' + esc(d) : ''}</div>`;
  }).join('');
  panel.classList.add('on');
}

export function renderPosts(posts) {
  const output = document.getElementById('output');
  const wrap = document.getElementById('posts-wrap');
  const title = document.getElementById('out-title');
  const rule = document.getElementById('output-rule');

  title.textContent = posts.length + ' post' + (posts.length > 1 ? 's' : '') + ' · ' + new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });

  wrap.innerHTML = '';
  posts.forEach((p, i) => {
    const lines = (p.body || '').split('\n');
    const bodyHtml = lines.map((l, idx) =>
      idx === 0 ? `<span class="phook">${esc(l)}</span>` : esc(l)
    ).join('\n');

    const card = document.createElement('div');
    card.className = 'pcard';
    card.dataset.index = i;
    card.innerHTML = `
      <div class="pc-corner pc-tl"></div>
      <div class="pc-corner pc-br"></div>
      <div class="pc-meta">
        <span class="pbadge ${p.platform === 'linkedin' ? 'p-li' : 'p-x'}">${p.platform === 'linkedin' ? 'LinkedIn' : 'X'}</span>
        <span class="ptag">${esc(p.pillar || '')}</span>
        <span class="ptag">${esc((p.type || '').replace(/_/g, ' '))}</span>
        ${p.fomo_mechanic ? `<span class="fomo-pill">${esc(p.fomo_mechanic)} fomo</span>` : ''}
      </div>
      <div class="ptext">${bodyHtml}</div>
      ${p.hashtags && p.hashtags.length ? `<div class="phashtags">${p.hashtags.map(h => `<span class="htag">${esc(h)}</span>`).join('')}${p.hashtag_rationale ? `<div class="htag-why">${esc(p.hashtag_rationale)}</div>` : ''}</div>` : ''}
      ${p.intelligence_note ? `<div class="pinsight"><div class="pi-label">Intelligence Layer</div><div class="pi-text">${esc(p.intelligence_note)}</div></div>` : ''}
      ${p.pacc_element ? `<div class="pacc-note"><div class="pacc-label">PACC Element</div><div class="pacc-text">${PACC_LABELS[p.pacc_element] || p.pacc_element}</div></div>` : ''}
      <div class="pc-actions">
        <button class="pact" data-action="copy" data-index="${i}">Copy</button>
        <button class="pact" data-action="regen" data-index="${i}">Regenerate</button>
      </div>
    `;
    wrap.appendChild(card);
  });

  rule.style.display = 'block';
  output.classList.add('on');
  output.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

export function copyPost(posts, i) {
  const p = posts[i];
  const hashtags = (p.hashtags && p.hashtags.length) ? '\n\n' + p.hashtags.join(' ') : '';
  const text = (p.body || '') + hashtags;
  navigator.clipboard.writeText(text).catch(() => {
    const t = document.createElement('textarea');
    t.value = text;
    document.body.appendChild(t);
    t.select();
    document.execCommand('copy');
    document.body.removeChild(t);
  });
  const btn = document.querySelector(`[data-action="copy"][data-index="${i}"]`);
  if (btn) {
    btn.textContent = 'Copied ✓';
    setTimeout(() => { btn.textContent = 'Copy'; }, 1600);
  }
}

export function copyAll(posts) {
  const text = posts.map(p => {
    const hashtags = (p.hashtags && p.hashtags.length) ? '\n\n' + p.hashtags.join(' ') : '';
    return `[${(p.platform || '').toUpperCase()} · ${p.pillar || ''} · ${(p.type || '').replace(/_/g, ' ')}]\n${p.body || ''}${hashtags}`;
  }).join('\n\n───────\n\n');
  navigator.clipboard.writeText(text).catch(() => {});
  const btn = document.querySelector('.copy-all-btn');
  if (btn) {
    btn.textContent = 'Copied ✓';
    setTimeout(() => { btn.textContent = 'Copy All'; }, 1600);
  }
}

export async function regenOne(posts, i) {
  const p = posts[i];
  const cards = document.querySelectorAll('.pcard');
  const card = cards[i];
  if (card) card.style.opacity = '0.3';
  const btn = document.querySelector(`[data-action="regen"][data-index="${i}"]`);
  if (btn) btn.textContent = '...';

  try {
    const regenPrompt = buildRegenPrompt(p);
    const reqBody = buildRequestBody({ system: SYSTEM, user: regenPrompt }, false, 1000);
    const data = await generateContent(reqBody, { maxOutputTokens: 1000 });
    const raw = extractText(data);
    const np = parseJsonResponse(raw);
    posts[i] = np;

    if (card) {
      card.style.opacity = '1';
      const pt = card.querySelector('.ptext');
      const lines = (np.body || '').split('\n');
      pt.innerHTML = lines.map((l, idx) => idx === 0 ? `<span class="phook">${esc(l)}</span>` : esc(l)).join('\n');
      const pi = card.querySelector('.pi-text');
      if (pi && np.intelligence_note) pi.textContent = np.intelligence_note;
      const pa = card.querySelector('.pacc-text');
      if (pa && np.pacc_element) pa.textContent = PACC_LABELS[np.pacc_element] || np.pacc_element;
    }
    if (btn) btn.textContent = 'Regenerate';
  } catch {
    if (card) card.style.opacity = '1';
    if (btn) btn.textContent = 'Regenerate';
  }
}
